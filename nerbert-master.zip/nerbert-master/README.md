# NER BERT

Pre-requisities:
- python3.x
- pip3

`pip3 intsall -r requirements.txt`

`ner_train.py` - обучение с CUDA.

`ner_predict.py` - модуль с функцией предсказания `tag_sent`. На вход массив строк. На выход массив массивов тегированных токенов.

