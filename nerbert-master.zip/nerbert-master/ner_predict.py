import pickle
import torch
from keras.preprocessing.sequence import pad_sequences
from pytorch_pretrained_bert import BertTokenizer
from pytorch_pretrained_bert import BertForTokenClassification

tag2idx = {'B-art': 5,
 'B-eve': 6,
 'B-geo': 10,
 'B-gpe': 16,
 'B-nat': 2,
 'B-org': 1,
 'B-per': 0,
 'B-tim': 9,
 'I-art': 14,
 'I-eve': 3,
 'I-geo': 13,
 'I-gpe': 11,
 'I-nat': 7,
 'I-org': 4,
 'I-per': 15,
 'I-tim': 12,
 'O': 8}

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased', do_lower_case=True)

loaded_model = pickle.load(open('nerbert_cpu.pkl', 'rb'))

def tag_sent(sentences):
  tokenized_sentences = [tokenizer.tokenize(sent) for sent in sentences]
  input_ids = torch.tensor(pad_sequences([tokenizer.convert_tokens_to_ids(txt) for txt in tokenized_sentences],
                          maxlen=75, dtype="long", truncating="post", padding="post"))
  result = loaded_model(input_ids)

  tagged_sents = []
  for sent_index, sent in enumerate(result):
    tagged_sent = []
    for word_index, word in enumerate(sent):
      temp = word.tolist()
      tag = list(tag2idx.keys())[list(tag2idx.values()).index(temp.index(max(temp)))]
      try:
        tagged_sent.append((tokenized_sentences[sent_index][word_index], tag))
      except:
        pass
    tagged_sents.append(tagged_sent)

  return tagged_sents

